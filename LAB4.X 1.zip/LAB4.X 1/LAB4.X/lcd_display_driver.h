void lcd_display_driver_enable();
    
void lcd_display_driver_clear();

void lcd_display_driver_initialize();

void lcd_display_driver_write( char* data, int length );

void display_driver_use_first_line( void );

void display_driver_use_second_line( void );

void delay_function();

void NU32_WriteUART2( char * string);