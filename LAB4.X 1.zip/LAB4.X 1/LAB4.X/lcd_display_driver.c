#include "lcd_display_driver.h"
#include <xc.h>

      
void NU32_WriteUART2( char * string){
    // Write a character array using UART2
    
    while(*string != '\0'){
        while(U2STAbits.UTXBF);
            U2TXREG = *string;
            // wait until tx buffer isnt full
            ++string;
        
    }
    
    
   
      
}

void lcd_display_driver_enable(){ // calling the delay function
    
    LATDbits.LATD4 = 1; // setting enable Register RD4 to 1 as an input
    delay_function();
    
    LATDbits.LATD4 = 0; // setting enable Register RD4 to 0 as an output
}

void delay_function(){
     int i;
    for(i = 0; i < 1000; i++){;}  // delay
   
}


void lcd_display_driver_initialize(){
    // Function Set - setting all the individual bits to match the function set
    LATBbits.LATB15 = 0;    // setting RS register bit RB15 to 0 
    LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 
    
    LATEbits.LATE7 = 0;     // setting DB7 registerbit RE7 to 0 
    LATEbits.LATE6 = 0;     // setting DB6 registerbit RE6 to 0
    LATEbits.LATE5 = 1;     // setting DB5 registerbit RE5 to 1 
    LATEbits.LATE4 = 1;     // setting DB4 registerbit RE4 to 1 
    LATEbits.LATE3 = 1;     // setting DB3 registerbit RE3 to 0 , for 2 line mode
    LATEbits.LATE2 = 0;     // setting DB2 registerbit RE2 to 0 , for 5 by 7 dots (F)
    // DB1 (RE1), and DB0 (RE0) are set to x, so they dont matter
   
    lcd_display_driver_enable(); // calling the delay function


    //Display ON/OFF Control - setting all the individual bits to match the Display set
    LATBbits.LATB15 = 0;    // setting RS register bit RB15 to 0 input
    LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 input
    
    LATEbits.LATE7 = 0;     // setting DB7 registerbit RE7 to 0 input
    LATEbits.LATE6 = 0;     // setting DB6 registerbit RE6 to 0 input
    LATEbits.LATE5 = 0;     // setting DB5 registerbit RE5 to 0 input
    LATEbits.LATE4 = 0;     // setting DB4 registerbit RE4 to 0 input
    LATEbits.LATE3 = 1;     // setting DB3 registerbit RE3 to 1 input, for 2 line mode
    LATEbits.LATE2 = 1;     // setting DB2 registerbit RE2 to 1 input, to set display on
    LATEbits.LATE1 = 0;     // setting DB2 registerbit RE2 to 1 input, to set cursor off
    LATEbits.LATE0 = 0;     // setting DB2 registerbit RE2 to 1 input, to set blink off
   
    lcd_display_driver_enable();   // calling the enable function


    lcd_display_driver_clear(); // calling the clear function


    lcd_display_driver_enable();   // // calling the enable function


    // Entry mode Set - setting all the individual bits to match the Entry Mode set
    LATBbits.LATB15 = 0;    // setting RS register bit RB15 to 0 
    LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 
    
    LATEbits.LATE7 = 0;     // setting DB7 registerbit RE7 to 0 
    LATEbits.LATE6 = 0;     // setting DB6 registerbit RE6 to 0 
    LATEbits.LATE5 = 0;     // setting DB5 registerbit RE5 to 0 
    LATEbits.LATE4 = 0;     // setting DB4 registerbit RE4 to 0 
    LATEbits.LATE3 = 0;     // setting DB3 registerbit RE3 to 0 
    LATEbits.LATE2 = 1;     // setting DB2 registerbit RE2 to 0 
    LATEbits.LATE1 = 1;     // setting DB2 registerbit RE2 to 1  to set increment on
    LATEbits.LATE0 = 0;     // setting DB2 registerbit RE2 to 1 to set entire shift off
     
    lcd_display_driver_enable();   // // calling the enable function  
}
   


void lcd_display_driver_clear(){
    LATBbits.LATB15 = 0;    // setting RS register bit RB15 to 0 input
    LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 input
    LATE = 0b00000001;      // setting (DB0 - 7) the whole register E( except to 1 ) to 0 input

    lcd_display_driver_enable();   // // calling the enable function
}




void lcd_display_driver_write( char* data, int length ){
    
    int i;
    for(i = 0; i < length; i++){
        LATBbits.LATB15 = 1;    // setting RS register bit RB15 to 1` input
        LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 input
        LATE = data[i];      // setting (DB0 - 7) the whole register E to data word
        lcd_display_driver_enable();   // // calling the enable function
    }  
    
}


void display_driver_use_first_line( void ){
    LATBbits.LATB15 = 0;    // setting RS register bit RB15 to 0` input
    LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 input
    LATE = 0x80;      // setting (DB0 - 7) the whole register E to first line 
    lcd_display_driver_enable();   // // calling the enable function

}


void display_driver_use_second_line( void ){
     LATBbits.LATB15 = 0;    // setting RS register bit RB15 to 0` input
     LATDbits.LATD5 = 0;     // setting RW register bit RD5 to 0 input
     LATE = 0xC0;      // setting (DB0 - 7) the whole register E to first line 
     lcd_display_driver_enable();   // // calling the enable function

}


